
</div>
<footer>
    <div class="container text-center">
        <div class="row">
            <div class="col-lg-12">
                <ul class="nav nav-pills nav-justified">
                    <li>© 2020 Galaxy Swiss Bourdins</li>
                </ul>
            </div>
        </div>
    </div>
</footer>
</body>
</html>


